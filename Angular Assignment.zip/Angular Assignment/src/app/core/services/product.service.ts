import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Product } from '../models/product.interface';

@Injectable({ providedIn: 'root' })
export class ProductService {
  private mockData: Product[] = [
    { id: 1, name: 'iPhone 15 Pro', price: 170199, category: 'Electronics', description: 'Titanium design, A17 Pro chip', image: 'assets/images/iphone15.png' },
    { id: 2, name: 'Nike Air Max', price: 14000, category: 'Fashion', description: 'Premium comfort running shoes.', image: 'assets/images/nike.png' },
    { id: 3, name: 'Sony WH-1000XM5', price: 3999, category: 'Electronics', description: 'Industry leading noise canceling.',image: 'assets/images/sony.png' },
    { id: 4, name: 'Herman Miller Chair', price: 12000, category: 'Furniture', description: 'Ergonomic office chair.',image: 'assets/images/hermanchair.png'  }
  ];
  private products$ = new BehaviorSubject<Product[]>(this.mockData);
  getProducts() { return this.products$.asObservable(); }
  getProductById(id: number) { return this.products$.value.find(p => p.id === id); }
  addProduct(p: Product) { 
    const current = this.products$.value; 
    const newId = Math.max(...current.map(x => x.id), 0) + 1;
    this.products$.next([...current, { ...p, id: newId }]); 
  }
  updateProduct(p: Product) {
    const current = this.products$.value;
    const idx = current.findIndex(x => x.id === p.id);
    if (idx !== -1) { current[idx] = p; this.products$.next([...current]); }
  }
  deleteProduct(id: number) { this.products$.next(this.products$.value.filter(p => p.id !== id)); }
}