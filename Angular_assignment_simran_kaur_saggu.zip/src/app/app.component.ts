import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatBadgeModule } from '@angular/material/badge';
import { CommonModule } from '@angular/common';
import { CartService } from './core/services/cart.service';
import { SearchService } from './core/services/search.service';
import { map } from 'rxjs';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterModule, MatToolbarModule, MatButtonModule, MatIconModule, MatBadgeModule, CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  count$ = this.cartSrv.getCart().pipe(map(i => i.reduce((a, b) => a + b.quantity, 0)));
  constructor(private cartSrv: CartService, private searchSrv: SearchService) { }
  onSearch(e: any) { this.searchSrv.setSearch(e.target.value); }
}