# Project Architecture
- **Standalone Components**: Removes NgModule boilerplate (Angular 15+ standard).
- **Core Services**: ProductService and CartService are singletons for state management.
- **Search Service**: Decoupled communication between Navbar (input) and List (table).
- **Material Design**: Uses professional typography and custom CSS variables.