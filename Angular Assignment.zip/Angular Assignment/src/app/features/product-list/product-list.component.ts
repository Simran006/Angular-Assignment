import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ProductService } from '../../core/services/product.service';
import { CartService } from '../../core/services/cart.service';
import { SearchService } from '../../core/services/search.service';
import { ConfirmDialogComponent } from '../../shared/components/confirm-dialog.component';
import { Product } from '../../core/models/product.interface';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatPaginatorModule, MatSortModule, MatButtonModule, MatIconModule, MatCardModule, MatButtonToggleModule, RouterModule, FormsModule, MatDialogModule, MatSnackBarModule],
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  displayedColumns = ['name', 'category', 'price', 'actions'];
  dataSource = new MatTableDataSource<Product>();
  viewMode = 'table';
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private productSrv: ProductService, private cartSrv: CartService, private searchSrv: SearchService, private dialog: MatDialog, private snack: MatSnackBar) {}

  ngOnInit() {
    this.productSrv.getProducts().subscribe(data => {
      this.dataSource.data = data;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
    this.searchSrv.searchTerm$.subscribe(term => this.dataSource.filter = term.trim().toLowerCase());
  }
  addToCart(p: Product) { this.cartSrv.addToCart(p); this.snack.open('Added to Cart', 'OK', { duration: 1500 }); }
  deleteProduct(p: Product) {
    this.dialog.open(ConfirmDialogComponent).afterClosed().subscribe(res => {
      if(res) { this.productSrv.deleteProduct(p.id); this.snack.open('Deleted', 'OK', { duration: 1500 }); }
    });
  }
}
