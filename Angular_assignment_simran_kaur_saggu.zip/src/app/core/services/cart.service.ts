import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CartItem, Product } from '../models/product.interface';

@Injectable({ providedIn: 'root' })
export class CartService {
  private cart$ = new BehaviorSubject<CartItem[]>(JSON.parse(localStorage.getItem('cart') || '[]'));
  getCart() { return this.cart$.asObservable(); }
  addToCart(product: Product) {
    const current = this.cart$.value;
    const existing = current.find(i => i.id === product.id);
    if (existing) { existing.quantity++; } else { current.push({ ...product, quantity: 1 }); }
    this.updateState(current);
  }
  updateQty(id: number, qty: number) {
    let current = this.cart$.value;
    const item = current.find(i => i.id === id);
    if (item) {
      item.quantity = qty;
      if (item.quantity <= 0) current = current.filter(i => i.id !== id);
      this.updateState(current);
    }
  }
  private updateState(items: CartItem[]) {
    this.cart$.next([...items]);
    localStorage.setItem('cart', JSON.stringify(items));
  }
}