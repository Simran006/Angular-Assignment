import { Routes } from '@angular/router';
import { ProductListComponent } from './features/product-list/product-list.component';
import { ProductFormComponent } from './features/product-form/product-form.component';
import { CartComponent } from './features/cart/cart.component';
export const routes: Routes = [
  { path: '', component: ProductListComponent },
  { path: 'add', component: ProductFormComponent },
  { path: 'edit/:id', component: ProductFormComponent },
  { path: 'cart', component: CartComponent }
];